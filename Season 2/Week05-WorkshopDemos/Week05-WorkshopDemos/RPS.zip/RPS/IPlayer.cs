﻿namespace RPS
{
    public interface IPlayer
    {
        Choice MakeChoice();

    }
}
