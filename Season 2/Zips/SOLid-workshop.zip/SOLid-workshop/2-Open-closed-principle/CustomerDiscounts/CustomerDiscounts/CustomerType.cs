﻿// File: CustomerType.cs

namespace CustomerDiscounts;

public enum CustomerType
{
    Regular,
    VIP,
    Seasonal
}
