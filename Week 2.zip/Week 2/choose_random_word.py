import random
list_of_words = ["Potato", "Carrot", "Eggplant", "Zucchini", "Tomato", "Cucumber"]
word = random.choice(list_of_words)
print(word)