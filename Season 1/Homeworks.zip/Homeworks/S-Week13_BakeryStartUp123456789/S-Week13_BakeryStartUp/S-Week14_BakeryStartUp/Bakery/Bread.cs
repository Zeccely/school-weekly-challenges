﻿public enum BreadType
{
    Ciabatta,
    Foccacia,
    Sour_Dough,
    Rye,
    Whole_Wheat
}