name= 'John Doe'

age= 30

salary= 2500.72

print(name)
print(age)
print(salary)

salary='Food'
print(salary)