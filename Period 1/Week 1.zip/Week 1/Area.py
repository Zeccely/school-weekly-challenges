radius=float(input('Enter Radius\n'))

area= 3.14*radius**2
circum= 2*3.14*radius

print((area,circum))